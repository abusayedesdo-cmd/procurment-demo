<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FinancialEvaluationReport extends Model
{
    use HasFactory;

    protected $fillable = [
        'rfq_id',
        'prepared_by',
        'report_file',
    ];

    public function rfq()
    {
        return $this->belongsTo(Rfq::class, 'rfq_id');
    }

    public function preparedBy()
    {
        return $this->belongsTo(User::class, 'prepared_by');
    }

    public function items()
    {
        return $this->hasMany(FinancialEvaluationItem::class, 'fer_id');
    }

}
